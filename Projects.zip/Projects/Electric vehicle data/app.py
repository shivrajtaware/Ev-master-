import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(layout="wide", page_title="EV Master Dashboard")


@st.cache_data
def load_ev_data(csv_path: str = "EV-Master-Dataset.csv"):
    try:
        df = pd.read_csv(csv_path)
    except Exception:
       
        np.random.seed(42)
        brands = ["Tesla","BMW","Audi","Mercedes-Benz","Hyundai","Kia","Nissan","BYD","Volkswagen","Renault","Ford","Volvo","Lucid","Rivian","XPeng","NIO","Toyota","Peugeot","Skoda","Tata","MG"]
        countries = {
            "Tesla":"United States","BMW":"Germany","Audi":"Germany","Mercedes-Benz":"Germany","Hyundai":"South Korea","Kia":"South Korea","Nissan":"Japan","BYD":"China","Volkswagen":"Germany","Renault":"France","Ford":"United States","Volvo":"Sweden","Lucid":"United States","Rivian":"United States","XPeng":"China","NIO":"China","Toyota":"Japan","Peugeot":"France","Skoda":"Czechia","Tata":"India","MG":"China"
        }
        regions_map = {"United States":"North America","Germany":"Europe","South Korea":"Asia","Japan":"Asia","China":"Asia","France":"Europe","Sweden":"Europe","Czechia":"Europe","India":"Asia"}
        models = ["Alpha","Beta","Gamma","Delta","Epsilon","Zeta","Sigma","Omega"]
        rows = 400
        data = []
        for _ in range(rows):
            b = np.random.choice(brands)
            country = countries[b]
            region = regions_map.get(country, "Europe")
            year = np.random.randint(2020, 2025)
            price = np.random.randint(20000, 130000)
            batt = np.random.randint(40, 130)
            eff = np.random.randint(115, 220)
            rng = int(batt * 1000 / eff) + np.random.randint(-30, 60)
            data.append({
                "Brand": b,
                "Model": f"{np.random.choice(models)} {np.random.randint(1,9)}",
                "Year": year,
                "Country": country,
                "Region": region,
                "Price_USD": price,
                "Range_km": max(180, rng),
                "Battery_kWh": batt,
                "Efficiency_Wh_km": eff,
                "Top_Speed_kmh": np.random.randint(140, 270),
                "Acceleration_0_100_s": round(np.random.uniform(2.7, 10.5), 1),
                "Charging_Time_hr": round(np.random.uniform(0.6, 2.2), 2),
                "Sales_Units": np.random.randint(5000, 120000),
                "Market_Share_Pct": round(np.random.uniform(0.2, 8.5), 2),
                "Seats": np.random.choice([4,5,6,7]),
                "Drive_Type": np.random.choice(["RWD","AWD","FWD"]),
                "Body_Type": np.random.choice(["Sedan","SUV","Crossover","Hatchback","Pickup"]),
                "FastCharge_kW": np.random.choice([80,100,120,150,170,200,220,250])
            })
        df = pd.DataFrame(data)
   
    df["Year"] = pd.to_numeric(df["Year"], errors="coerce")
    df["Price_USD"] = pd.to_numeric(df["Price_USD"], errors="coerce")
    df["Range_km"] = pd.to_numeric(df["Range_km"], errors="coerce")
    df["Battery_kWh"] = pd.to_numeric(df["Battery_kWh"], errors="coerce")
    df["Efficiency_Wh_km"] = pd.to_numeric(df["Efficiency_Wh_km"], errors="coerce")
    df["Sales_Units"] = pd.to_numeric(df["Sales_Units"], errors="coerce")
    df.dropna(subset=["Year","Price_USD","Range_km","Battery_kWh","Efficiency_Wh_km"], inplace=True)
    return df

df = load_ev_data()

st.sidebar.title("Filters")
brands = st.sidebar.multiselect("Brand", sorted(df["Brand"].unique()), default=sorted(df["Brand"].unique())[:8])
regions = st.sidebar.multiselect("Region", sorted(df["Region"].unique()), default=sorted(df["Region"].unique()))
countries = st.sidebar.multiselect("Country", sorted(df["Country"].unique()), default=[])
yr_min, yr_max = int(df["Year"].min()), int(df["Year"].max())
year_range = st.sidebar.slider("Year Range", yr_min, yr_max, (yr_min, yr_max))
price_min, price_max = float(df["Price_USD"].min()), float(df["Price_USD"].max())
price_sel = st.sidebar.slider("Price (USD)", price_min, price_max, (price_min, price_max))

mask = (
    df["Brand"].isin(brands) &
    df["Region"].isin(regions) &
    (df["Year"].between(year_range[0], year_range[1])) &
    (df["Price_USD"].between(price_sel[0], price_sel[1]))
)
if countries:
    mask &= df["Country"].isin(countries)

f = df[mask].copy()

st.title("🚗⚡ EV Master Analysis Dashboard")

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Avg Price (USD)", f"${f['Price_USD'].mean():,.0f}")
k2.metric("Avg Range (km)", f"{f['Range_km'].mean():.0f}")
k3.metric("Avg Battery (kWh)", f"{f['Battery_kWh'].mean():.1f}")
k4.metric("Total Sales (Units)", f"{f['Sales_Units'].sum():,.0f}" if "Sales_Units" in f else "—")
k5.metric("Avg Eff. (Wh/km)", f"{f['Efficiency_Wh_km'].mean():.0f}")

st.markdown("---")

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📈 Trends", "📊 Comparisons", "⚡ Efficiency", "🌍 Regional & Map", "🧮 Correlation", "📋 Data & Export"
])

with tab1:
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Range Over Time (by Brand)")
        fig = px.line(f, x="Year", y="Range_km", color="Brand", markers=True)
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        st.subheader("Price Over Time (by Brand)")
        fig = px.line(f, x="Year", y="Price_USD", color="Brand", markers=True)
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Sales Over Time (All Selected)")
    if "Sales_Units" in f.columns:
        ts = f.groupby("Year", as_index=False)["Sales_Units"].sum().sort_values("Year")
        fig = px.bar(ts, x="Year", y="Sales_Units", text_auto=True)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No Sales_Units column available.")

with tab2:
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Price vs Range (bubble = Battery)")
        fig = px.scatter(f, x="Range_km", y="Price_USD", size="Battery_kWh", color="Brand",
                         hover_data=["Model","Country","Year"])
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        st.subheader("Top Selling Brands")
        if "Sales_Units" in f.columns:
            top_sales = f.groupby("Brand", as_index=False)["Sales_Units"].sum().sort_values("Sales_Units", ascending=False).head(12)
            fig = px.bar(top_sales, x="Brand", y="Sales_Units", color="Brand", text_auto=True)
            st.plotly_chart(fig, use_container_width=True)

    st.subheader("Price Distribution by Brand (Box Plot)")
    fig = px.box(f, x="Brand", y="Price_USD", points="outliers")
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Battery vs Range")
        fig = px.scatter(f, x="Battery_kWh", y="Range_km", color="Brand", trendline="ols", hover_data=["Model"])
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        st.subheader("Efficiency (Wh/km) Distribution")
        fig = px.histogram(f, x="Efficiency_Wh_km", nbins=30, color="Brand")
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Charging Time vs FastCharge Power")
    if "FastCharge_kW" in f.columns:
        fig = px.scatter(f, x="FastCharge_kW", y="Charging_Time_hr", color="Brand", hover_data=["Model"])
        st.plotly_chart(fig, use_container_width=True)

with tab4:
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Sales by Region")
        if "Sales_Units" in f.columns:
            by_region = f.groupby("Region", as_index=False)["Sales_Units"].sum().sort_values("Sales_Units", ascending=False)
            fig = px.bar(by_region, x="Region", y="Sales_Units", color="Region", text_auto=True)
            st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.subheader("Avg Price by Country")
        avg_price = f.groupby("Country", as_index=False)["Price_USD"].mean().sort_values("Price_USD", ascending=False)
        fig = px.choropleth(avg_price, locations="Country", locationmode="country names",
                            color="Price_USD", color_continuous_scale="Viridis",
                            title="Average Price by Country")
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Market Share by Brand (Pie)")
    if "Market_Share_Pct" in f.columns:
        share = f.groupby("Brand", as_index=False)["Market_Share_Pct"].mean().sort_values("Market_Share_Pct", ascending=False).head(12)
        fig = px.pie(share, names="Brand", values="Market_Share_Pct")
        st.plotly_chart(fig, use_container_width=True)

with tab5:
    st.subheader("Correlation Heatmap")
    num_cols = ["Price_USD","Range_km","Battery_kWh","Efficiency_Wh_km","Top_Speed_kmh","Acceleration_0_100_s","Charging_Time_hr","Sales_Units","Market_Share_Pct","FastCharge_kW"]
    existing = [c for c in num_cols if c in f.columns]
    if existing:
        corr = f[existing].corr()
        fig, ax = plt.subplots(figsize=(10,6))
        sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax)
        st.pyplot(fig)
    else:
        st.info("No numeric columns available for correlation.")

with tab6:
    st.subheader("Filtered Dataset")
    st.dataframe(f, use_container_width=True, height=420)

    csv = f.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download filtered CSV", csv, file_name="EV-Filtered.csv", mime="text/csv")

    st.caption("Tip: Put EV-Master-Dataset.csv in the same folder as this app. If missing, a synthetic dataset is generated so the app still works.")

